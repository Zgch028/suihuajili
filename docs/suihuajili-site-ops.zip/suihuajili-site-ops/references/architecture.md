# 站点架构速查（architecture）

## 目录结构

SITE_ROOT = `F:/安宇公司技术文件/龙山大佛工作台/岁华纪丽网_astro`
（动手前先 Glob / ls 确认实际路径）

```
SITE_ROOT/
├── src/
│   ├── content/
│   │   ├── series/        # 系列页 markdown（每个系列一个 {slug}.md）
│   │   └── posts/         # 文章 markdown（每篇一个 {slug}.md）
│   ├── content.config.ts  # zod schema：series / posts 字段定义（单一事实来源）
│   ├── data/site.ts       # SITE 元信息 + NAV_LINKS 顶部导航
│   ├── layouts/BaseLayout.astro   # 全站 {head}：SEO meta、baidu 验证
│   ├── pages/
│   │   ├── series/[slug].astro    # 系列页渲染 + 页头背景遮罩
│   │   ├── posts/[slug].astro     # 文章页渲染
│   │   ├── about.astro            # 关于页（含公众号二维码入口）
│   │   └── index.astro            # 首页
│   └── components/        # Nav / Footer / ArticleCard / JsonLd 等
├── public/
│   ├── series-bg/         # 系列页头背景图（jpg）
│   ├── images/posts/      # 文章配图、封面
│   ├── card/              # 数字名片（index.html 紫罗兰版 / light.html 浅色版 / *.png）
│   ├── images/wechat-official-qr.jpg  # 公众号二维码
│   ├── robots.txt / sitemap.xml        # 已自动生成 / 手写
│   └── baidu_verify_codeva-*.html      # 百度文件验证残留（标签验证已生效，可留）
├── .github/workflows/deploy.yml   # GitHub Actions 部署
└── docs/                  # 迁移指南、盘点表、模板
```

## content.config.ts schema

### series 字段

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| title | string | ✓ | 系列名（页面 H1） |
| eyebrow | string | ✓ | 页头小标签，如「SERIES · 宋文化」 |
| description | string | ✓ | 系列简介（同时用于页头副文与 meta description 兜底） |
| tag | string | ✓ | 卡片分类标签 |
| seoTitle | string | ✓ | 本页 `{title}` |
| seoDescription | string | ✓ | 本页 meta description |
| seoKeywords | string[] | ✓ | 本页 meta keywords |
| order | number | 默认 99 | 首页系列网格排序 |
| headerImage | string? | 可选 | 页头背景图路径，如 `/series-bg/qingming-header.jpg` |

### posts 字段

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| title | string | ✓ | 文章完整标题 |
| date | date (YYYY-MM-DD) | ✓ | 发布日期 |
| series | string | ✓ | 对应 series 的 slug（必须已存在） |
| description | string | ✓ | 摘要（列表卡 + meta description 兜底） |
| tags | string[] | 默认 [] | 标签 |
| cover | string? | 可选 | 封面图路径 `/images/posts/xxx.jpg` |
| volume | string? | 可选 | 年卷标识，如「公元969年卷」 |

> frontmatter 写错（缺必填字段 / 类型不符）会导致 `npm run build` 失败，schema 是第一道校验。

## 导航配置（src/data/site.ts）

- `NAV_LINKS`：数组，每项 `{ label, href }`，控制顶部导航与页头返回。
- 新增系列后，若要在导航显示，在 `NAV_LINKS` 追加一项（label 中文、href `/series/{slug}`）。
- `SITE` 对象含 `author`（赵国成）、`matrix`（公众号 / 视频号 / 微信）等元信息，改名片文案先来这里。

## 系列页渲染与遮罩（src/pages/series/[slug].astro）

是否配 `headerImage` 决定套用哪套样式：

- **有背景图** → 加 `series-header--with-bg` 类 → 宣纸亮调遮罩：
  - 遮罩渐变：`linear-gradient(90deg, rgba(247,240,226,0.94) 0%, rgba(247,240,226,0.78) 42%, rgba(247,240,226,0.30) 100%)`
  - 文字：墨字 `#2a241c` / 金眉 `#9a7b2e` / 暖灰副文 `#5b5346` / 半透明宣纸 SEO 卡 `rgba(255,252,246,0.74)`
- **无背景图** → 默认 Navy 深蓝底 + 白字 + 金眉标 + 深蓝 SEO 面板。

⚠️ 亮调文字配色**必须**写在 `.series-header--with-bg` 作用域内，切勿提到全局 `.series-header`，否则无背景图系列页文字会变墨色看不见（曾因此返工）。
