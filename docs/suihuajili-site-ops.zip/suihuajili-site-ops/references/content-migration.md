# 内容迁移：从得到大脑笔记（GetNotes）搬文章

两种来源，按链接形态选方法。

## 方法 A：单篇共享链接直读（最省力）

适用：`https://www.biji.com/note/share_note/{id}` 或 `biji.com/note/share_note/{id}`

1. 用户发 share_note 链接。
2. 直接 `WebFetch(url, "Extract the full note title and complete body text...")` 抓完整正文（公开分享页，无需 API、不写账号）。
3. 清洗：
   - 以 GetNotes 作品稿标题为准（可能与公众号盘点表差一两个字，如「存爱入福」vs「存爱入褶」）。
   - 去除首尾创作注解（视觉说明、作者留言、审阅提示）。
   - 章节小标题 `###` 提为 `##`；内标题 `###` 去重。
   - 正文一字不改搬入，保留原有段落 / 列表 / 引用。
4. 套用 `assets/post-template.md` frontmatter，写 `src/content/posts/{slug}.md`，底部保留原文链接注。
5. 本地 `NODE_OPTIONS= npm run build` 校验。

## 方法 B：知识库 topic 批量迁移

适用：`https://biji.com/topic/{id}`（WebFetch 取不到笔记列表，需 API）

1. 加载 getnote-kb-assess 技能（Skill: getnote-kb-assess）获取授权读取能力。
2. 用其 `fetch_topic.py` 全量拉取：
   `python <getnote-kb-assess>/fetch_topic.py {topic_id} docs/notes.json`
   （脚本已硬编码读取 `~/.openclaw/openclaw.json` 授权，返回含 content 全文的数组，note_id 为字符串）
3. 定位目标篇：按标题精确匹配（注意作品稿标题差异）。可借助本技能 `scripts/getnotes_topic_list.py` 打印清单：
   `python scripts/getnotes_topic_list.py {topic_id} --keyword 春节`
4. 逐篇清洗（同方法 A 第 3 步）。常见需剔除：
   - `【视觉说明】` 配图说明
   - 「文章已就绪！请您审阅…」作者留言
   - **保留**：作者自填诗词（如端午《水调歌头·端午》属正文创作）、文末 💫 互动（文章原生结尾）
5. 统一 frontmatter（date 用文章内日期推算或盘点表日期；volume / cover 按需），写 md。
6. 清理临时 json，build 校验。

## 清洗规则速记

- 作品稿 vs 盘点表：以作品稿标题 / 措辞为准。
- 首尾创作注解：删。
- 章节层级：`###` → `##`；内 H3 标题行去。
- 正文：一字不改，保留列表 / 引用 / 诗词。
- 底部：加「本文首发于公众号「岁华纪丽」，原文链接：…」来源注。

## 盘点与分工

- 合集级盘点：`docs/公众号内容盘点表.xlsx`（表头：公众号合集名 / 对应网站 series slug / 文章标题 / 发布日期 / 原文链接 / 是否搬运）。
- 文章级数据需用户从后台或 GetNotes 提供，AI 不代劳后台权限。
- 迁移 SOP 与 FAQ 见 `docs/公众号内容迁移指南.md`（站点内）。
