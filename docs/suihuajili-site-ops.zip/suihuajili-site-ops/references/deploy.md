# 部署上线（deploy）

## 标准链路（推荐）

1. 本地改完内容：`git add -A && git commit -m "类型: 简述"`。
2. **用户在 GitHub Desktop 点 Push origin**（main 分支）。
3. GitHub Actions（`.github/workflows/deploy.yml`）自动：checkout → setup-node 22 → npm ci → npm run build → cloudflare/pages-action 部署到项目 `suihuajili`。
4. 验证：`https://suihuajili.cn/<路径>` 返回 200、内容更新。

## 关键配置（deploy.yml）

- `permissions: contents: read / deployments: write`（pages-action 需创建 Deployment 状态，缺 write 会 403）。
- Secrets：`CLOUDFLARE_API_TOKEN`、`CLOUDFLARE_ACCOUNT_ID`（仓库 Repository secrets，已配置；**切勿写入技能或本地文件**）。
- 触发：`push: branches: [main]` 或 `workflow_dispatch` 手动。

## 沙箱限制与应对

- 本环境 `git push` 常因 SSL 握手失败（多次复现）。**不要反复在沙箱重试**。
  → 改请用户在 GitHub Desktop 点 Push origin。
- 直投 `wrangler pages deploy dist --project-name=suihuajili` 因凭证敏感通常被拦截，仅作历史备用路径，不作为常规。

## 本地构建

- 绕过沙箱 safe-delete shim：`NODE_OPTIONS= npm run build`（在项目根目录）。
- 构建失败先查 frontmatter schema 校验（缺必填字段 / 类型错）。

## 上线验证

- `curl -sI https://suihuajili.cn/series/{slug}/` 看 200。
- 或开浏览器核对渲染。
