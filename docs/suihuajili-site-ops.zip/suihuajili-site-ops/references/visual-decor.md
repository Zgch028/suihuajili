# 视觉装饰：系列页头、数字名片、SEO

## 系列页头背景图

- 在 series md 加 `headerImage: /series-bg/<图>.jpg`（路径相对 public）。
- 把背景图放到 `public/series-bg/`，建议 1920 宽横图。
- 若图偏暗：用 sharp 轻微提亮
  `sharp(input).modulate({ brightness: 1.08, saturation: 1.04 }).toFile(output)`
- 遮罩自动切宣纸亮调（见 architecture.md 遮罩规则），无需改 CSS。
- 已上线案例：大宋纪丽 → 清明上河图风格；十二生肖 → 齐白石册页风格（高对比版，右侧遮罩 0.30 透出笔墨）。

## 数字名片（public/card/）

- 紫罗兰版（默认）：`index.html`，背景 `#8a7bb5 → #6d5c94 → #4e3f6b`，米白字 + 金点缀，含电话 `13546339366` / 地址 `山西·太原` / 真人头像。
- 浅色水墨版：`light.html`，米白宣纸底 `#f5efe1 → #ece4d0 → #ddd2b8` + 淡墨山影 + 墨字 `#2a241c` + 暖金眉标 `#9a7b2e`，同含电话地址头像。
- 改版后用 puppeteer-core + 系统 Chrome 重渲染 PNG：
  `node render-light.cjs`（浅色）或对应渲染脚本（紫罗兰版）。
- 在线地址：`/card/`（紫罗兰）、`/card/light.html`（浅色）。

## SEO 收录

- BaseLayout 已挂百度验证 meta：`baidu-site-verification`（值 `codeva-sl6Vk5ldwE`）。
- robots.txt / sitemap.xml / 首页 JSON-LD（WebSite / Person / SearchAction）已上线。
- 百度提交：
  - 手动提交通道可提交核心 URL（无需备案）。
  - sitemap 提交额度与 ICP 备案号绑定，未备案站点每日额度 0，输入框禁用；备案后回平台填备案号解锁。
- Bing Webmaster 不强制国内备案，可单独安排。
- 站点改动后，部署上线即可被蜘蛛抓取；新站收录约 1~7 天。
