#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
getnotes_topic_list.py — 列出得到大脑笔记（GetNotes）知识库 topic 下的笔记，定位待迁移的目标篇。

用法：
  python getnotes_topic_list.py <topic_id> [--keyword 春节] [--out notes.json]

依赖：
  getnote-kb-assess 技能提供的 fetch_topic.py（复用其授权读取逻辑，读取 ~/.openclaw/openclaw.json）。

流程：
  1. 调用 fetch_topic.py 全量拉取 topic 笔记到 <out> JSON
  2. 打印每篇笔记：序号 / note_id / 是否含正文 / 标题
  3. 若给 --keyword，高亮标题命中的篇，方便核对 note_id 后做清洗落盘
"""

import sys
import json
import argparse
from pathlib import Path

GETNOTE_FETCH = Path.home() / ".workbuddy/skills/getnote-kb-assess/fetch_topic.py"


def main():
    ap = argparse.ArgumentParser(description="列出 GetNotes 知识库 topic 笔记并定位目标篇")
    ap.add_argument("topic_id", help="GetNotes 知识库 topic id，如 mnyy4EAn")
    ap.add_argument("--keyword", help="按标题关键词过滤 / 高亮目标篇")
    ap.add_argument("--out", default="docs/getnotes_notes.json", help="拉取结果输出路径")
    args = ap.parse_args()

    if not GETNOTE_FETCH.exists():
        print(f"❌ 未找到 getnote-kb-assess 技能的 fetch_topic.py：{GETNOTE_FETCH}")
        print("请先加载该技能：Skill: getnote-kb-assess")
        sys.exit(1)

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    print(f"🔍 拉取 topic {args.topic_id} ...")
    try:
        subprocess_run = __import__("subprocess").run
        subprocess_run(
            [sys.executable, str(GETNOTE_FETCH), args.topic_id, str(out_path)],
            check=True,
        )
    except Exception as e:
        print(f"❌ 拉取失败：{e}")
        sys.exit(1)

    notes = json.loads(out_path.read_text(encoding="utf-8"))
    print(f"\n📋 共 {len(notes)} 篇笔记：")
    for i, n in enumerate(notes, 1):
        title = (n.get("title") or "")
        nid = n.get("note_id") or n.get("id")
        has = bool((n.get("content") or "").strip())
        flag = " <<< 匹配" if (args.keyword and args.keyword in title) else ""
        print(f"{i:02d}. id={nid} content={has} | {title}{flag}")

    if args.keyword:
        hits = [n for n in notes if args.keyword in (n.get("title") or "")]
        print(f"\n✅ 关键词「{args.keyword}」命中 {len(hits)} 篇，请在上方清单核对 note_id。")


if __name__ == "__main__":
    main()
